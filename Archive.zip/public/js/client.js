const answerForm = document.forms.answer;
// console.log(answer);
const see = document.querySelector('.otvet');
// console.log(see);

answerForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const { action, method } = event.target;
  console.log(action);
  const formData = new FormData(event.target);
  const data = Object.fromEntries(formData);
  const response = await fetch(action, {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });
  // console.log(response);
  const answer = await response.json();
  console.log(answer)
  if (response.ok) {
    see.innerHTML = answer;
    event.target.reset();
  }

  // console.log(answer);
});
