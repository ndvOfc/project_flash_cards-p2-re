const express = require('express');
const config = require('./config/config');
const mainRouter = require('./routes/main.route');
const questionRouter = require('./routes/question.route');
const loginRouter = require('./routes/login.routes')

const app = express();

config(app);

app.use('/', loginRouter)

app.use('/main', mainRouter);

app.use('/', questionRouter);

app.listen(3000, () => console.log('listen port 3000'));
